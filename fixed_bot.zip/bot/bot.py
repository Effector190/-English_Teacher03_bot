import os
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
from openai import OpenAI

load_dotenv()

TG_TOKEN = os.getenv("TG_BOT_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
WEBHOOK_URL = os.getenv("WEBHOOK_URL")  # https://your-app.onrender.com
PORT = int(os.getenv("PORT", 8080))

if not TG_TOKEN:
    raise ValueError("TG_BOT_API_KEY not found in .env")

if not OPENAI_API_KEY:
    raise ValueError("OPENAI_API_KEY not found in .env")

client = OpenAI(api_key=OPENAI_API_KEY)

user_modes = {}

SYSTEM_PROMPT = '''
Role:
You are a personal English teacher.

The student level is A1-A2 with a very small vocabulary.

You actively teach:
- correct mistakes
- explain rules simply in Russian
- show natural spoken English

Modes must NOT mix.

MODE 1 - /check

Format:

✅ Исправленная версия:
[correct sentence]

📝 Разбор:
1. mistake -> correction
Правило: simple explanation
В живой речи говорят: natural version

💡 Слово / фраза дня

MODE 2 - /translate

Format:

✅ Твой вариант: user sentence
✔️ Правильно: corrected

📝 Разбор

💡 Слово / фраза дня

If user sends only Russian sentence — ask them to try translating first.

MODE 3 - /chat

Reply with simple A2 English.

---
📝 Разбор
💡 Слово / фраза дня

Rules:

- explanations ONLY in Russian
- English must be simple
- no long introductions
'''


def ask_ai(mode, text):
    prompt = f"Mode: {mode}\nUser message: {text}"
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message.content


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "English Teacher Bot\n"
        "/check — проверка текста\n"
        "/translate — проверка перевода\n"
        "/chat — разговор\n"
        "/voice — голос"
    )


async def set_mode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    mode = update.message.text.replace("/", "")
    user_modes[update.effective_user.id] = mode
    await update.message.reply_text(f"Режим: {mode}")


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    mode = user_modes.get(user_id)
    if not mode:
        await update.message.reply_text("Выбери режим: /check /translate /chat /voice")
        return
    answer = ask_ai(mode, text)
    await update.message.reply_text(answer)


async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    file = await update.message.voice.get_file()
    path = f"voice_{user_id}.ogg"
    await file.download_to_drive(path)
    with open(path, "rb") as audio:
        transcript = client.audio.transcriptions.create(
            model="whisper-1",
            file=audio
        )
    text = transcript.text
    answer = ask_ai("check", text)
    await update.message.reply_text(f"🎤 Расшифровка:\n{text}\n\n{answer}")
    os.remove(path)


def main():
    app = ApplicationBuilder().token(TG_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("check", set_mode))
    app.add_handler(CommandHandler("translate", set_mode))
    app.add_handler(CommandHandler("chat", set_mode))
    app.add_handler(CommandHandler("voice", set_mode))

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.VOICE, handle_voice))

    print("Bot started...")

    if WEBHOOK_URL:
        app.run_webhook(
            listen="0.0.0.0",
            port=PORT,
            url_path=TG_TOKEN,
            webhook_url=f"{WEBHOOK_URL}/{TG_TOKEN}"
        )
    else:
        app.run_polling()


if __name__ == "__main__":
    main()
