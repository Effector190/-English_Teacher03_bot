Telegram English Teacher Bot

Python version: 3.13

Setup:

1. Install dependencies
pip install -r requirements.txt

2. Create .env file
copy .env.example to .env

3. Add your keys
TG_BOT_API_KEY=...
OPENAI_API_KEY=...

4. Run
python bot.py

Commands:

/check
check english text

/translate
check translation

/chat
simple english conversation

/voice
send voice message, bot will transcribe and correct